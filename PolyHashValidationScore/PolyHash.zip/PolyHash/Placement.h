#ifndef HASHCODE18_PLACEMENT_H
#define HASHCODE18_PLACEMENT_H

#include <string>
#include <vector>
#include "Map.h"

using namespace std;

class Placemenet {

public:


private:


};




#endif //HASHCODE18_PLACEMENT_H